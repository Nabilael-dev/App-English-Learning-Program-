import { useRouter } from 'next/router';
import useSWR from 'swr';

const fetcher = (url: string) => fetch(url).then(res => res.json());

export default function LessonPage() {
  const { query } = useRouter();
  const { data: lesson, error } = useSWR(query.id ? `/api/lessons/${query.id}` : null, fetcher);

  if (error) return <div>Error loading lesson.</div>;
  if (!lesson) return <div>Loading...</div>;

  return (
    <main className="p-8">
      <h2 className="text-2xl font-bold mb-4">{lesson.title}</h2>
      {lesson.videoUrl && (
        <video controls src={lesson.videoUrl} className="mb-4 w-full max-w-2xl rounded" />
      )}
      <p className="mb-2">{lesson.description}</p>
      {/* Render interactive activities here */}
      <div>
        {lesson.activities.map((activity: any, idx: number) => (
          <div key={idx} className="mb-4 p-4 bg-gray-100 dark:bg-gray-700 rounded">
            <p>{activity.prompt}</p>
            {/* Render activity type: multiple choice, fill-in-blank, drag-drop etc. */}
          </div>
        ))}
      </div>
    </main>
  );
}